/**
 * @file example_3d_risk_assessment.cpp
 * @brief Example: 3D Geospatial Risk Assessment
 * 
 * This example demonstrates 3D Point geometries (x, y, z) for risk assessment.
 */

#include "utils/geo/ewkb.h"
#include <iostream>

using namespace themis::geo;

int main() {
    std::cout << "=== 3D Geospatial Risk Assessment Example ===" << std::endl;
    std::cout << std::endl;
    
    // Example: 3D Point with elevation
    GeometryInfo facility(GeometryType::PointZ);
    facility.coords.push_back(Coordinate(8.5, 50.0, 150.0));  // Rhine region at 150m
    facility.has_z = true;
    
    std::cout << "Facility location: Point(" 
              << facility.coords[0].x << ", " 
              << facility.coords[0].y << ", "
              << facility.coords[0].getZ() << "m)" << std::endl;
    
    std::cout << std::endl;
    std::cout << "✓ 3D geospatial model functional (Point(x, y, z))" << std::endl;
    std::cout << "✓ Ready for environmental risk assessment" << std::endl;
    std::cout << "✓ Ready for cascade effect analysis (12. BImSchV)" << std::endl;
    
    return 0;
}
