# Exporters Documentation

**Stand:** 5. Dezember 2025  
**Version:** 1.0.0  
**Kategorie:** Exporters

---

## Übersicht

ThemisDB bietet Export-Funktionen für LLM-Training und Multi-LoRA-Integration.

## Features

| Feature | Status | Beschreibung |
|---------|--------|--------------|
| JSONL LLM Exporter | ✅ Production | Training Data Export |
| LoRA Adapter Metadata | ✅ Production | Adapter Configuration |
| vLLM Multi-LoRA | ✅ Production | Multi-LoRA Serving |

## Dokumentation in diesem Ordner

| Datei | Beschreibung |
|-------|--------------|
| [IMPLEMENTATION_SUMMARY.md](IMPLEMENTATION_SUMMARY.md) | Implementation Overview |
| [JSONL_LLM_EXPORTER.md](JSONL_LLM_EXPORTER.md) | JSONL Export für LLM Training |
| [LORA_ADAPTER_METADATA.md](LORA_ADAPTER_METADATA.md) | LoRA Adapter Konfiguration |
| [VLLM_MULTI_LORA_INTEGRATION.md](VLLM_MULTI_LORA_INTEGRATION.md) | vLLM Multi-LoRA Integration |

## Verwandte Dokumentation

- [LLM Module](../llm/README.md) - LLM Integration
- [API Documentation](../api/README.md) - Export APIs
